package org.packt.swarm.petstore.cart;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class CartApplication extends Application {
}
