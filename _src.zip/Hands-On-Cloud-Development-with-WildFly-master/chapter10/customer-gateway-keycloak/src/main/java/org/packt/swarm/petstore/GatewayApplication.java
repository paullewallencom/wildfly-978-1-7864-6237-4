package org.packt.swarm.petstore;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class GatewayApplication extends Application {
}
